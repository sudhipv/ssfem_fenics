API documentation (Python)
==========================

**Work in progress**

The Python documentation is missing, see our `old docs
<https://fenicsproject.org/olddocs/dolfin/>`_ for now.

Full API
--------

We should split this somehow

.. automodule:: dolfin
   :members:
   :undoc-members:

