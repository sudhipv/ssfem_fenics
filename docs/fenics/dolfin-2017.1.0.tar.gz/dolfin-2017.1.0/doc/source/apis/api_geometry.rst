dolfin/geometry
================================================================================
Documentation for C++ code found in ``dolfin/geometry/*.h``

.. include:: ../../generated_rst_files/api_gen_geometry.rst

