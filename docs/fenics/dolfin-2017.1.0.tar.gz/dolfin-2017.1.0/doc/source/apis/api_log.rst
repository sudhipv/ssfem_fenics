dolfin/log
================================================================================
Documentation for C++ code found in ``dolfin/log/*.h``

.. include:: ../../generated_rst_files/api_gen_log.rst

