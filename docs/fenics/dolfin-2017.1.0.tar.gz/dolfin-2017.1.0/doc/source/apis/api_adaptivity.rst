dolfin/adaptivity
================================================================================
Documentation for C++ code found in ``dolfin/adaptivity/*.h``

.. include:: ../../generated_rst_files/api_gen_adaptivity.rst

