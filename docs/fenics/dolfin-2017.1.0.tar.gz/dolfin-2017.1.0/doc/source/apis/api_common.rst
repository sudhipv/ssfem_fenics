dolfin/common
================================================================================
Documentation for C++ code found in ``dolfin/common/*.h``

.. include:: ../../generated_rst_files/api_gen_common.rst

