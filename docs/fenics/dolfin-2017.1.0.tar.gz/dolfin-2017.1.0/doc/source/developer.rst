.. DOLFIN developer documentation

Developer resources
===================

DOLFIN development takes place on `Bitbucket
<https://bitbucket.org/fencis-project/dolfin>`_. For information about how to
get involved and how to get in touch with the developers, see our `community
page <https://fenicsproject.org/community/>`_.


.. toctree::
   :maxdepth: 2

   styleguide_cpp
   documenting_dolfin_api
