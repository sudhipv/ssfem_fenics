Dolfin documentation
====================

Run "make html" to build the web pages. This will run doxygen to generate xml
files documenting the C++ code and then use generate_api_rst.py / 
parse_doxygen.py to generate docstrings for SWIG and RST API files for Sphinx

TODO: fix Sphinx API docs for the Python code and describe here how it all fits
together with the mocking of .so files and everything that entails
