#!/bin/sh
# Clean out old log files

rm -f assemble-poisson*.log*
rm -f solve-poisson*.log*
