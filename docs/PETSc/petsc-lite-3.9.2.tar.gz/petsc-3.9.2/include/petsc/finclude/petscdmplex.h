!
!
!  Include file for Fortran use of the DMPlex package in PETSc
!
#if !defined (__PETSCDMPLEXDEF_H)
#define __PETSCDMPLEXDEF_H

#include "petsc/finclude/petscdm.h"
#include "petsc/finclude/petscdmlabel.h"

#endif
