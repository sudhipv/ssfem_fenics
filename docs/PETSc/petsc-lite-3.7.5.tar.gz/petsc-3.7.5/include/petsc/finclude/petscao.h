!
!
!  Include file for Fortran use of the AO (application ordering) package in PETSc
!
#include "petsc/finclude/petscaodef.h"

!
!  End of Fortran include file for the AO package in PETSc
